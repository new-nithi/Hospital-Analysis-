-- KPI & Analysis Queries (SQLite)

-- 1) Appointments per day
SELECT appointment_date AS day, COUNT(*) AS appt_count
FROM appointments
GROUP BY day
ORDER BY day;

-- 2) Peak appointment hour
SELECT strftime('%H', appointment_time) AS hour, COUNT(*) AS appt_count
FROM appointments
GROUP BY hour
ORDER BY appt_count DESC;

-- 3) Appointment status distribution
SELECT status AS status, COUNT(*) AS cnt
FROM appointments
GROUP BY status
ORDER BY cnt DESC;

-- 4) Top reasons for visit
SELECT reason_for_visit AS reason, COUNT(*) AS cnt
FROM appointments
GROUP BY reason
ORDER BY cnt DESC
LIMIT 10;

-- 5) Appointments per doctor
SELECT a.doctor_id AS doctor_id, COUNT(*) AS appt_count
FROM appointments a
GROUP BY doctor_id
ORDER BY appt_count DESC;

-- 6) 30-day revisit rate
WITH ap AS (SELECT patient_id pid, date(appointment_date) d FROM appointments)
SELECT ROUND(100.0 * SUM(has_revisit) / COUNT(*), 2) AS revisit_rate_pct
FROM (
  SELECT a1.pid, a1.d,
         CASE WHEN EXISTS (
              SELECT 1 FROM ap a2
              WHERE a2.pid = a1.pid
                AND a2.d > a1.d
                AND julianday(a2.d) - julianday(a1.d) <= 30
         ) THEN 1 ELSE 0 END AS has_revisit
  FROM ap a1
);

-- 7) Treatment cost summary
SELECT treatment_type AS treatment_type,
       COUNT(*) AS n_cases,
       ROUND(AVG(cost),2) AS avg_cost,
       ROUND(SUM(cost),2) AS total_cost
FROM treatments
GROUP BY treatment_type;

-- 8) Monthly treatment cost trend
SELECT strftime('%Y-%m', treatment_date) AS ym, ROUND(SUM(cost),2) AS total_cost
FROM treatments
GROUP BY ym
ORDER BY ym;